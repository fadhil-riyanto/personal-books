#ifndef MAZE_H_INCLUDED
#define MAZE_H_INCLUDED

#ifdef X11
#include <X11/X.h>
#include <X11/Xlib.h>
#endif

#include <math.h>

#define SIZE 10			/* ilo�� p�l (w poziomie i pionie) */
#define CELL_SIZE 50		/* wymiary pola (kwadrat) */
#define AVATAR_SIZE 10		/* wymiary obserwatora (kwadrat) */
#define MIN_DIST 0.1		/* minimalna odleg�o�� od obsewatora */

#define MIN_Y	(-CELL_SIZE/2.0) /* wysoko�� �cian */
#define MAX_Y	(+CELL_SIZE/2.0)

#define SCREEN_WIDTH  320	/* rozmiary */
#define SCREEN_HEIGHT 200	/* ekranu */
#define SCREEN_ASPECT ((float)SCREEN_WIDTH)/((float)SCREEN_HEIGHT)

/* rodzaje kolizji obserwatora ze �cianami */
#define NO_COLLISION		0x0 /* brak kolizji */
#define COLLISION		0x1 /* kolizja (og�lnie) */
#define SLIDE_COLLISION_X	0x1 /* kolizja, ale mo�na porusza� si� wzd�u� OX */
#define SLIDE_COLLISION_Y	0x2 /* kolizja, ale mo�na porusza� si� wzd�u� OZ */
#define HARD_COLLISION		0x3 /* kolizja, nie mo�a si� poruszy� */

/**** typy danych ***********************************************************/

typedef int			int16;
typedef long int		int32;
typedef unsigned char		byte;
typedef unsigned int		word;
typedef unsigned long int	dword;
typedef dword			uint32;

/* wierzcho�ek */
typedef struct {
	float x,z;	/* wsp�rz�dne wierzcho�ka */
	float xt,zt;	/* wsp�rz�dne wierzcho�ka po przeksza�ceniach */
	char side;	/* czy punkt po przekszta�ceniach znajduje  */
			/* si� za, czy przed obserwatorem */
	dword lightness;
} Vertex;

/* kraw�d� */
typedef struct {
	Vertex *A, *B;	/* wska�niki do wierzcho�k�w */
	char exist;	/* kraw�d� istnieje */
	byte color;	/* kolor (tmp!!!) */
} Edge;

/* pozycja obsewatora */
extern float angle;	/* kierunek */
extern float xo, zo;	/* wsp�rz�dne */
extern float speed;	/* pr�dko�� */
extern float d;		/* ogniskowa wirtualnej kamery */
extern void (*draw_wall)(float, float, float, float, const Edge*, float, float);

/*** Funkcje *****************************************************************/

void error(const char*);

void make_maze();
int  collision(float dx, float dz);
void draw_maze();

int perspective_view_xcoord(float x, float y, float z);
int perspective_view_ycoord(float x, float y, float z);

#endif
