/*****************************************************************************

	W pliku znajduje si� interfejs do ekranu. Program u�ywa podw�jnego
buforowania tzn. obraz rysowany jest w obszarze pami�ci poza pami�ci video
(z ang. offscreen), a dopiero po narysowaniu jest przerzucany na ekran.
Dzi�ki temu u�ytkownik nie widzi "na bie��co" procedury rysowania obrazu;
obraz nie mruga.
	Procedury zawarte w tym pliku ustawiaj� tryb graficzny 13h
320x200x256c (init_screen), ustawiaj� tryb tekstowy 03h 80x25 (close_screen),
ustawiaj� palet� karty VGA (set_LUT; u�ywa rejestr�w karty). Ponadto
procedura clear_screen czy�ci bufor obrazu (a dok�adniej wype�nia zadanym
kolorem). Procedura show_screen wy�wietla obraz na ekranie (przepisuje obraz
z pami�ci programu do pami�ci karty graficznej); procedura ta mo�e oczekiwa�
na zako�czenie rysowania obrazu na monitorze i przerzuci� dane w czasie
powrotu pionowego plamki monitora (sprawdzaj�c stosowne bity z rejestr�w
stanu karty VGA). Redukuje to artefakty, kt�re polegaj� na tym, �e "nagle"
w po�owie obrazu pojawia si� nowy, zmieniony obraz.

*****************************************************************************/

#include "screen.h"
#include "draw.h"
#include "maze.h"

#ifdef BC
#include <dos.h>
#include <mem.h>
#include <string.h>
#include <stdlib.h>
#include <alloc.h>
#endif

int init_screen() {
	/* ustawienie trybu 13h */
	union REGS regs;

	regs.h.ah = 0x00;	// funkcja
	regs.h.al = 0x13;
	int86(0x10, &regs, &regs);

	return 1;
}

void close_screen() {
	/* ustawienie trybu 03h */
	union REGS regs;

	regs.h.ah = 0x00;	// funkcja
	regs.h.al = 0x03;
	int86(0x10, &regs, &regs);
}

void set_single_LUT(byte i, byte r, byte g, byte b) {
	outportb(0x3C8, i);
	outportb(0x3C9, r);
	outportb(0x3C9, g);
	outportb(0x3C9, b);
}

void set_LUT() {
	unsigned int i;
	union REGS regs;

	for (i=0; i<64; i++) {
		set_single_LUT(i+0*64, i, i, i);
		set_single_LUT(i+1*64, i, 0, 0);
		set_single_LUT(i+2*64, 0, i, 0);
		set_single_LUT(i+3*64, 0, 0, i);
	}
}

void show_image(
	byte far image[SCREEN_HEIGHT][SCREEN_WIDTH],
	byte wait_v_retrace) {

	if (wait_v_retrace) {
		// czekaj na rozpocz�cie rysowanie
		// (gdy trafimy na odrysowanie "�rodka" ekranu)
		while ((inportb(0x3da) & 0x8) != 0);
		// czekaj na zako�czenie rysowania
		while ((inportb(0x3da) & 0x8) == 0);
	}
	_fmemcpy(MK_FP(0xA000, 0x0000), image_buffer, 64000);
}

void clear_image(
	byte far image[SCREEN_HEIGHT][SCREEN_WIDTH],
	byte color) {
	_fmemset(image, color, SCREEN_HEIGHT*SCREEN_WIDTH);
}
/*
vim ts=8
*/
