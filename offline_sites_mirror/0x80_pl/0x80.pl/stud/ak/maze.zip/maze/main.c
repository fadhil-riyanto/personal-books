/*

        Architektura komputer�w -- projekt: labirynt

        Wykona�: Wojciech Mul/a 2FD/L03; semestr letni 2004

        Program wykonany w ramach projetku, ma umo�liwia� u�ytkownikowi
  poruszanie si� po tr�jwymiarowym labiryncie. Labirynt jest generowany
  losowo. Pr�dko�� wy�wietlania obraz�w ma by� ca�kowicie niezale�na od
  pr�dko�ci komputera. U�ytkownik mo�e nacisn�� dowoln� liczb� klawiszy
  jednocze�nie.

  1. Przerwanie zegarowe
  ======================

  Przerwanie zegarowe jest generowane 64 razy szybciej ni� standardowo,
  a wi�c procedura obs�ugi przerwania sprz�towego 0x9 jest wywo�ywana
  co ok. 1.1ms. W tej procedurze, co 64 takty wo�ana jest stara
  procedura obs�ugi przerwania, dzi�ki czemu DOS-owy zegar systemowy
  "tyka" bez zmian.
  W procedurze obs�ugi przerwania zrealizowano ca�y mechanizm poruszania
  obserwatorem, uzyskuj�c sta�� pr�dko�� jego poruszania. Natomiast
  program g��wny wizualuzuje scen� 3d zgodnie z po�o�eniem obserwatora
  z tak� pr�dko�ci�, jaka jest tylko mo�liwa.

  2. Przerwanie klawiatury
  ========================

  Przerwanie klawiatury jest standardowe -- do tablicy 128 bajt�w
  wpisywane s� stany poszczeg�lnych klawiszy. W pliku nag��wkowym
  scanc.h zdefiniowano te kody klaiwszy, kt�re s� potrzebne w programie.

*/

#include <stdlib.h>
#include <stdio.h>
#include <math.h>

#include <dos.h>
#include <values.h>

#include "maze.h"       /* tworzenie labiryntu, kolizje */
#include "draw.h"       /* rysowanie */
#include "screen.h"     /* ekran na kt�rym rysowany jest obraz */
#include "scanc.h"      /* kody klawiszy */

static char* __="Wojciech Mul/a, kwiecien' 2004";

#define true    1
#define false   0

volatile unsigned char key_map[128]; /* mapa wci�ni�tych klawiszy */
volatile byte last;
volatile int redraw;

void error(const char* info) {
        //fputs(info, stderr);
}

void help() {
        puts("Klawisze:");
        puts("* ESC - koniec");
        puts("* m   - wylosowanie nowego labiryntu");
        puts("* v   - synchronizacja z monitorem");

        puts("* poruszanie sie po labiryncie:");
        puts("  # -> - obrot w lewo");
        puts("  # <- - obrot w prawo");
        puts("  # /\ - do przodu");
        puts("  # \/ - do tylu");
        puts("  # Alt + ->  - przesuniecie w lewo (ang. strafe)");
        puts("  # Alt + <-  - przesuniecie w prawo (ang. strafe)");
        puts("  # Shift     - bieganie");

        puts("* renderowanie labiryntu");
        puts("  # 1 lub f - cieniowanie plaskie (flat)");
        puts("  # 2 lub g - cieniowanie Gourauda");
        puts("  # 3 lub t - teksturowanie (na razie niedopracowane)");
        puts("    teksturowanie");
        puts("    n - nastepna tekstura");
        puts("    p - poprzednia tekstura");
        puts("    tekstury to pliki zawierajace bitampy 64x64 piksele");
        puts("    w skali szarosci, ktorych nazwy sa podawane z linii polecen");

        puts("");
        puts("Nacisnij enter...");

        getchar();
}

#define EOI outportb(0x20, 0x20)
#define flush_keyboard_buffer while (kbhit()) getch();

#define DIVIDER 64
void interrupt (*prev_clock_handler)();
void interrupt clock_handler() {
        static c = 0;

        char move = 0;
        float dx, dz;
        float Speed;
        disable();

#define ShiftPressed    (key_map[K_shiftL] || key_map[K_shiftR])
#define AltPressed      (key_map[K_alt])

        Speed = (ShiftPressed)  ? 2*speed : speed;
        if (key_map[K_left]) {
                if (AltPressed) {
                        dx = +Speed*cos(angle);
                        dz = -Speed*sin(angle);
                        move = true;
                }
                else {
                        if (ShiftPressed)
                                angle -= 0.002;
                        else
                                angle -= 0.001;
                        redraw = true;
                }
        }
        if (key_map[K_right]) {
                if (AltPressed) {
                        dx = -Speed*cos(angle);
                        dz = +Speed*sin(angle);
                        move = true;
                }
                else {
                        if (ShiftPressed)
                                angle += 0.002;
                        else
                                angle += 0.001;
                        redraw = true;
                }
        }
        if (key_map[K_up]) {
                dx = -Speed*sin(angle);
                dz = -Speed*cos(angle);
                move = true;
        }
        if (key_map[K_down]) {
                dx = Speed*sin(angle);
                dz = Speed*cos(angle);
                move = true;
        }

        if (move) {
                switch (collision(dx, dz)) {
                        case NO_COLLISION:
                                xo += dx;
                                zo += dz;
                                redraw = true;
                                break;
                        case SLIDE_COLLISION_X:
                                xo += dx;
                                redraw = true;
                                break;
                        case SLIDE_COLLISION_Y:
                                zo += dz;
                                redraw = true;
                                break;
                        case HARD_COLLISION:
                                break;
                }
        }
        enable();
        if (c == 0)
                prev_clock_handler();
        c = (c+1) & (DIVIDER - 1);
}

void interrupt (*prev_keyboard_handler)();
void interrupt keyboard_handler() {
 byte b, c;

 disable();
 c = inportb(0x60);
 b = inportb(0x61);
 outportb(0x61, b | 0x80);
 outportb(0x61, b | 0x00);
 enable();

 key_map[c & 0x7f] = ((c & 0x80) == 0x00);
 EOI;
}

void set_div(unsigned int div) {
 outportb(0x43, 0x36);
 outportb(0x40, (div>>0) & 0xff);
 outportb(0x40, (div>>8) & 0xff);
}

int main(int argc, char* argv[])
{
        int tex_num, tex_lo, tex_hi;
        byte retrace = 0;

        help();

        if (!init_screen())
                return 0;
        set_LUT();
        prepare_lookups();

        if (argc > 1) {
                tex_hi = argc - 1;
                tex_lo = tex_num = 1;
                load_texture(argv[tex_num]);
        }
        else {
		//tex_num = -1;
                load_texture("");
        }

        speed = CELL_SIZE/1000.0;
        make_maze();

        flush_keyboard_buffer;

        prev_keyboard_handler = getvect(0x9);
        prev_clock_handler = getvect(0x1c);
        setvect(0x9, keyboard_handler);
        setvect(0x1c, clock_handler);
        set_div(65536/DIVIDER);

        redraw  = true;
	retrace = true;
	draw_wall = draw_flat_wall;
        while (1) {
                // zako�czenie pracy programu
                if (key_map[K_ESC]) {
                        break;
                }

                // nast�pna tekstura
                if (key_map[K_n] && (tex_num > -1)) {
                        if (tex_num < tex_hi) {
                                load_texture(argv[++tex_num]);
                                redraw = true;
                        }
                        key_map[K_n] = 0;
                }

                // poprzednia tekstura
                if (key_map[K_p] && (tex_num > -1)) {
                        if (tex_num > tex_lo) {
                                load_texture(argv[--tex_num]);
                                redraw = true;
                        }
                        key_map[K_p] = 0;
                }

                // rendering
                // flat
                if (key_map[K_1] || key_map[K_f]) {
                        draw_wall = draw_flat_wall;
                        redraw = true;
                }

                // gouraud
                if (key_map[K_2] || key_map[K_g]) {
                        draw_wall = draw_shaded_wall;
                        redraw = true;
                }
                // teksturowanie
                if (key_map[K_3] || key_map[K_t]) {
                        draw_wall = draw_textured_wall;
                        redraw = true;
                }

                if (key_map[K_v]) {
                        retrace = !retrace;
                        key_map[K_v] = 0;
                }

                if (key_map[K_m]) {
                        make_maze();
                        key_map[K_m] = 0;
                        redraw = true;
                }
                if (redraw) {
                        redraw = false;
                        clear_image(image_buffer, 32);
                        draw_maze();
                        show_image(image_buffer, retrace);
                }
        }

end:
        close_screen();
        setvect(0x9, prev_keyboard_handler);
        set_div(0);
        setvect(0x1c, prev_clock_handler);
        return 0;
}
