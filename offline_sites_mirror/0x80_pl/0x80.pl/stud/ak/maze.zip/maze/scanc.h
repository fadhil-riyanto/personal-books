#ifndef scancodes_h_included
#define scancodes_h_included

#define K_ESC	0x1
#define K_esc	0x1
#define K_1	0x2
#define K_2	0x3
#define K_3	0x4

#define K_T	0x14
#define K_t	0x14

#define K_f	0x21
#define K_F	0x21

#define K_g	0x22
#define K_G	0x22

#define K_n	0x31
#define K_N	0x31

#define K_p	0x19
#define K_P	0x19

#define K_m	0x32
#define K_M	0x32

#define K_v	0x2f
#define K_V	0x2f

#define K_dot	0x33
#define K_comma	0x34

#define K_left	0x4b
#define K_right	0x4d
#define K_up	0x48
#define K_down	0x50

#define K_enter	0x1c

#define K_alt	0x38
#define K_shiftL	0x2a
#define K_shiftR	0x36

#endif
