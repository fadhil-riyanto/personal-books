/*********************************************************************

1. Wst�p
========

	Plik zawiera struktury przechowuj�ce struktur� labiryntu, oraz
procedury z tym zwi�zane. Labirnt jest rozpi�ty na regularnej siatce
wierzcho�k�w; jego struktura jest zapisana w dw�ch, a w�a�ciwie trzech
tablicach: dwuwymiarowej tablicy wierzcho�k�w, oraz dw�ch tablic �cian.
Struktury opisuj�ce �ciany zawieraj� indeksy do tablicy wierzcho�k�w,
bowiem jeden wierzcho�ek by� wsp�lny dla max. 4 kraw�dzi; takie
podej�cie oszcz�dza pami�� i redukuj� ilo�� oblicze�.
	�ciany s� zapisane w dw�ch tablicach: jedna odpowiada za
�ciany r�wnoleg�e do osi OX, druga OZ. To rozwi�zanie jest najprostsze
i znacznie upraszcza wykrywanie kolizji z obserwatorem.

2. Obserwator
=============

	Obserwatora opisuj� nast�puj�ce parametry:
1. Rozmiar - obserwator znajduje si� w kwadracie o pewnym boku
2. Po�o�enie - wsp�rz�dne (X, 0, Z), wskazuj�ce �rodek tego kwadratu 
3. K�t - k�t obrotu
4. Wysoko�� - wsp�rz�dna Y, tutaj 0

3. Kolizje
==========

	Obserwatora przemieszczaj�cego si� po labiryncie ograniczaj�
�ciany. Procedury sprawdzaj�ce tzw. kolizje testuj� czy przy
przemieszczeniu o wektor (dx, dz) obserwator (kwadrat) zderza si�
z jak�� �cian�. �eby by� bardziej precyzyjnym stwierdza si�, czy
mo�liwy jest ruch o wektor (0, dz) oraz (dx, 0). Je�li �aden nie
jest mo�liwy to obserwator jest "zablokowany" i nie mo�e si� porusza�.
Dzieje si� tak w dw�ch przypadkach: gdy "idzie" w stron� naro�nika
dw�ch �cian

	-----o
	     |
	   x |
	     |

	lub gdy pr�buje wej�� w "wisz�c�" �cian�, tzn. tak� kt�ra nie
styka si� z �adn� inn�.


	     x ------

	Podczas sprawdzania kolizji, testowane s� tylko cztery
najbli�sze �ciany, tzn. te �ciany, do kt�rych nale�y najbli�szy
obserwatorowi wierzcho�ek.

  
**********************************************************************/ 

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <assert.h>

#include "maze.h"
#include "draw.h"

#include <dos.h>

/* adresowanie: tablica[z][x] */
/* lista wierzcho�k�w */
Vertex vertex[SIZE+1][SIZE+1];

/* listy kraw�dzi: r�wnoleg�ych do osi OX i r�wnoleg�ych do osi OZ */
Edge edges_x[SIZE+3][SIZE+3], edges_z[SIZE+3][SIZE+3];

//char img[200*320*2];

float angle=0.0;	/* kierunek */
float xo=0.0, zo=0.0;	/* wsp�rz�dne */
float speed=4;		/* pr�dko�� */

void (*draw_wall)(float, float, float, float, const Edge*, float, float);

float d = -2*AVATAR_SIZE;	/* ogniskowa wirtualnej kamery */

void make_maze() {
#define i x
	int x, z;
	
	xo = floor(xo/CELL_SIZE)*CELL_SIZE + 0.5*CELL_SIZE;
	zo = floor(zo/CELL_SIZE)*CELL_SIZE + 0.5*CELL_SIZE;

	/* wype�nienie tablicy vertex */
	for (z=0; z<SIZE+1; z++)
		for (x=0; x<SIZE+1; x++) {
			vertex[z][x].x = x*CELL_SIZE;
			vertex[z][x].z = z*CELL_SIZE;
		}

	/* wyzerowanie tablic edges_x oraz edges_y */
	for (z=0; z<SIZE+3; z++)
		for (x=0; x<SIZE+3; x++) {
		edges_x[z][x].A = edges_x[z][x].B = NULL;
			edges_z[z][x].A = edges_z[z][x].B = NULL;
			edges_x[z][x].exist = edges_z[z][x].exist = 0;
#define thershold 85
			edges_x[z][x].color = (rand() % 100 > thershold) ? (rand() % 256) & 0xc0 : 0;
			edges_z[z][x].color = (rand() % 100 > thershold) ? (rand() % 256) & 0xc0 : 0;
#undef thereshold
		}

	/* wype�nienie tablicy edges_x */
	for (z=1; z<SIZE+2; z++) {
		for (x=1; x<SIZE+1; x++) {
#define e edges_x[z][x]
		e.A = &vertex[z-1][x-1];
		e.B = &vertex[z-1][x-0];
		e.exist = rand() % 2;
#undef e
		}
	}

	/* obramowanie */
	for (i=1; i<SIZE+1; i++) {
		edges_x[1][i].exist = edges_x[SIZE+1][i].exist = 1;
		edges_x[1][i].color = edges_x[SIZE+1][i].color = 0x00;
	}

	/* wype�nienie tablicy edges_z */
	for (z=1; z<SIZE+1; z++) {
		for (x=1; x<SIZE+2; x++) {
#define e edges_z[z][x]
		e.A = &vertex[z-1][x-1];
		e.B = &vertex[z-0][x-1];
		e.exist = rand() % 2;
#undef e
		}
	}

	/* obramowanie */
	for (i=1; i<SIZE+1; i++) {
		edges_z[i][1].exist = edges_z[i][SIZE+1].exist = 1;
		edges_z[i][1].color = edges_z[i][SIZE+1].color = 0x00;
	}
#undef i
}

void transform() {

	int i,j;
	float cos_a, sin_a, d, xo1, zo1;

	disable();
	sin_a = sin(angle);
	cos_a = cos(angle);

	xo1 = xo;
	zo1 = zo;
	enable();

	/* Obr�t+przesuni�cie */
	for (i=0; i<SIZE+1; i++)
		for (j=0; j<SIZE+1; j++) {
#define V vertex[i][j]
			V.xt = (V.x-xo1) * cos_a - (V.z-zo1) * sin_a;
			V.zt = (V.x-xo1) * sin_a + (V.z-zo1) * cos_a;
			V.side = V.zt <= MIN_DIST;

#define MAX ((float)(SIZE)*CELL_SIZE)
			d = (V.xt*V.xt + V.zt*V.zt + 0.1);
			d /= 2*MAX*MAX;
			d  = 63*(1-sqrt(d));
			V.lightness = (dword)(65536*d);
#undef MAX
#undef V
		}
}

int perspective_view_xcoord(float x, float y, float z)
{ return floor((SCREEN_ASPECT*SCREEN_WIDTH*x)/(z+d)) + SCREEN_WIDTH/2; } 

int perspective_view_ycoord(float x, float y, float z)
{ return floor((-SCREEN_HEIGHT*y)/(z+d)) + SCREEN_HEIGHT/2; }

void (*draw_wall)(float, float, float, float, const Edge*, float, float);

void draw_edge(Edge* E) {
	float x,z,t;
	float xa,xb,za,zb,u0,u1;
	char swap;
	
	if (!E) return;
	if (E->exist && E->A && E->B) 
	{
		if (!E->A->side && !E->B->side)
			return;
		if (E->A->side && E->B->side) {
			if (E->color)
				draw_glass_wall(E->A->xt, E->A->zt, E->B->xt, E->B->zt, E, 0.0, 1.0);
			else
				draw_wall(E->A->xt, E->A->zt, E->B->xt, E->B->zt, E, 0.0, 1.0);
		}
		else { /* clip */
			if (E->A->side) {
				xa = E->A->xt;
				za = E->A->zt;
				xb = E->B->xt;
				zb = E->B->zt;
				swap = 0;
			}
			else { /* E->B->side */
				xa = E->B->xt;
				za = E->B->zt;
				xb = E->A->xt;
				zb = E->A->zt;
				swap = 1;
			}

			z = MIN_DIST;
			t = (z-za)/(zb-za);
			x = xa + t*(xb-xa);

			if (swap) {
				u0 = 1.0;
				u1 = 1.0-t;
			}
			else {
				u0 = 0.0;
				u1 = t;
			}

			if (E->color)
				draw_glass_wall(xa, za, x, z, E, u0, u1);
			else
				draw_wall(xa, za, x, z, E, u0, u1);
		}
	}
}

int collision_with_wall(float xo, float yo, float xa, float xb, float y)
{
	float tmp;
	if (xa > xb) { tmp = xa; xa = xb; xb = tmp; }
	return ( (y >= yo-AVATAR_SIZE) && (y <= yo+AVATAR_SIZE) && (xo >= xa-AVATAR_SIZE) && (xo <= xb+AVATAR_SIZE) ) ? COLLISION : NO_COLLISION;
}

int collision_x(Edge* E, float xo, float yo) {
	if (E)
		return collision_with_wall(xo, yo, E->A->x, E->B->x, E->A->z);
	else
		return NO_COLLISION;
}

int collision_z(Edge* E, float xo, float yo) {
	if (E)
		return collision_with_wall(yo, xo, E->A->z, E->B->z, E->A->x);
	else
		return NO_COLLISION;
}

int collision(float dx, float dz) {
	int x, z;
	int rx, ry;
	char fx, fz;
	int count = 0;
	Edge *ZA = NULL, *XA = NULL, *ZB = NULL, *XB = NULL;
	
	x = floor(xo/CELL_SIZE)+1;
	z = floor(zo/CELL_SIZE)+1;

	fx = xo > x*CELL_SIZE - CELL_SIZE/2;
	fz = zo > z*CELL_SIZE - CELL_SIZE/2;
#define Z(x,z, dest) \
	if (edges_z[z][x].exist) { \
		dest = &edges_z[z][x]; \
		count++; \
	}

#define X(x,z, dest) \
	if (edges_x[z][x].exist) { \
		dest = &edges_x[z][x]; \
		count++; \
	}
	switch (fx + 2*fz) {
		case 0:
			Z(x,z, ZA);
			X(x,z, XA);

			Z(x,z-1, ZB);
			X(x-1,z, XB);
			break;
		case 1: 
			Z(x+1,z, ZA);
			X(x,z, XA);
			
			Z(x+1,z-1, ZB);
			X(x+1,z, XB);
			break;
		case 2: 
			Z(x,z, ZA);
			X(x,z+1, XA);

			Z(x,z+1, ZB);
			X(x-1,z+1, XB);
			break;
		case 3:
			Z(x+1,z, ZA);
			X(x,z+1, XA);

			Z(x+1,z+1, ZB);
			X(x+1,z+1, XB);
			break;
	}

	/* sprawd� czy je�li przesuniemy si� wzd�u� osi X */
	/* nie natrafimy na �cian� */
	rx = collision_z(ZA, xo+dx, zo) || collision_z(ZB, xo+dx, zo)
		? SLIDE_COLLISION_Y
		: NO_COLLISION;
	/* sprawd� czy je�li przesuniemy si� wzd�u� osi Y */
	/* nie natrafimy na �cian� */
	ry = collision_x(XA, xo, zo+dz) || collision_x(XB, xo, zo+dz)
		? SLIDE_COLLISION_X
		: NO_COLLISION;
		
	if (count==1 && rx==NO_COLLISION && ry==NO_COLLISION) {
		if (collision_z(ZB, xo+dx, zo+dz) || collision_x(XB, xo+dx, zo+dz))
			return HARD_COLLISION;
	}

	return rx + ry;
#undef X
#undef Z
}

int sort_fun(const void *element1, const void *element2) {
	const Edge *e1, *e2;
	float d1, d2, x, z;
	e1 = *(const Edge**)element1;
	e2 = *(const Edge**)element2;

	x  = (e1->A->xt+e1->B->xt)/2;
	z  = (e1->A->zt+e1->B->zt)/2;
	d1 = x*x + z*z;

	x  = (e2->A->xt+e2->B->xt)/2;
	z  = (e2->A->zt+e2->B->zt)/2;
	d2 = x*x + z*z;
	
	return (d1 > d2) - (d1 < d2);
}

void draw_maze() {
	int fill = 0;
	static Edge *edge_list[((SIZE+1)*SIZE)*2];

	int z,x,i;

	transform();

	for (z=0; z<SIZE+3; z++)
		for (x=0; x<SIZE+3; x++) {
#define ez edges_z[z][x]
#define ex edges_x[z][x]
			if (ez.exist && ez.A != NULL && ez.B != NULL && (ez.A->side || ez.B->side))
				edge_list[fill++] = &ez;
			if (ex.exist && ex.A != NULL && ex.B != NULL && (ex.A->side || ex.B->side))
				edge_list[fill++] = &ex;
#undef ez
#undef ex
		}

	assert(fill < ((SIZE+1)*SIZE)*2);
	qsort(edge_list, fill, sizeof(edge_list[0]), sort_fun);
	init_zbuffer();
	for (i=0; i<fill; i++) {
		draw_edge(edge_list[i]);
		assert(check_zbuffer_consistency() == 1);

		if (zbuffer_full())
			break;
	}
}
