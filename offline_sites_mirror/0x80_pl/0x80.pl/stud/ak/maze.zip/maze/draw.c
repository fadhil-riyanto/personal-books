/****************************************************************************

1. Procedury rysuj�ce �ciany
============================

	Ze wzgl�du na charakter geometrii �cian, podstawow� "jednostk�"
s�u��c� do ich rysowania s� odcinki pionowe. Jest tak, poniewa� �ciany zawsze
s� trapezami r�wnoramiennymi, kt�rych podstawy s� r�wnlog�e do osi OY.
Rysowanie takiej figury jest bardzo proste, sprowadza si� do obliczenia
przyrost�w dy/dx (w programie jako liczby fixedpoint 16:16) dla g�rnej
i dolnej kraw�dzi, a nast�pnie w p�tli od x0 do x1 rysowane s� odcinki
pionowe:

	wej�cie: (x0, y00, y01), (x1, y10, y11)

	dx  = x1-x0
	dy0 = (y10 - y00)/dx;
	dy1 = (y11 - y01)/dx;
	for x := x0 to x1 do
		linia_pionowa(x, y00, y01);
		y00 += dy0;
		y01 += dy1;

	Do rysowanie linii pionowych s�u�� dwie funkcje: draw_flat_vline,
rysuj�ca lini� o zadanym kolorze, oraz draw_textured_vline kt�ra rysuje
lini�, pobieraj�c kolory z biez�cej tekstury. Procedury te same obcinaj�
odcinki do okna (0,0)-(320,200).
	Funkcje rysuj�ce �ciany tylko si� do nich odwo�uj�, same za� zamuj�
si� nieco bardziej "og�lnymi" sprawami: widoczno�ci�, przezroczysto�ci�,
o�wietelniem itd.

2. Widoczno�� �cian
===================

	Wyznaczanie widoczno�ci �cian jest bardzo uproszczone, poniewa�:
* �ciany s� rozmieszczone regularnie
* nie s� samoprzecinaj�ce si�
* obserwator jest umieszczony w punkcie (x,0,z).

Je�li dwie linie pionowe nale��ce do r��nych �cian, maj� by� narysowane na
tej samej wsp��rz�dnej x, to odcinek le��cy bli�ej (mniejsze z) na pewno
zakryje odcinek bardziej oddalony

			 |
		    z	 |      |
	obserwator --->  |      |
			 |      |
			 |
			 z1  <  z2

	Dzi�ki temu problem widoczno�ci sprowadza si� faktycznie do jednego
wymiaru. �ciany s� rysowane w kolejno�ci od najbli�szej do najdalszej,
i jednocze�nie wype�niany jest bufor Z, kt�ry okre�la jakie obszary (jakie
przedzia�y na osi X) s� ju� zaj�te. Je�li fragment �ciany pokrywa si� z
ju� zaj�tym przedzia�em, to oczywi�cie nie jest on rysowany. Rysowanie ko�czy
si� albo po narysowaniu wszystkich �cian, albo gdy ca�y przedzia� X
(od 0 do 319) jest zaj�ty (co zwraca funkcja zbuffer_full). Bufor Z jest
opisywany przedzia�ami (a nie per piksel), ze wzgl�du na szybko�� (szybsze
obcinanie, mniej test�w widoczno�ci).
	Sam algorytm zakrywania jest bardzo prosty i w zasadzie sprowadza si�
do podj�cia 3 decyzji: przerwanie rysowania, narysowanie "pocz�tku" �ciany
i sprawdzanie reszty, dorysowania "ko�c�wki" �ciany" i zako�czenia.

3. Przezroczysto��
==================

	Je�li rysowana jest �ciana przezroczysta, to uwzgl�dniana jest
zawarto�� bufora Z, ale sama �ciana nie wp�ywa na ten bufor (oczywi�cie
w przeciwie�stwie do zwyk�ych, nieprzezroczystych �cian). Modyfikuje
natomiast bufor "zabarwienia" (glass), kt�ry przypisuje ka�dej linii pionowej
przezroczysto�� (0 - brak przezroczysto�ci, 1,2,3 (przesuni�te o 6 bit�w
w lewo) - przezroczysto��). Procedury rysuj�ce �ciany nieprzezorczyste
modyfikuj� kolor linii (za pomoc� operacji color | glass[x]), co jest bardzo
szybkie.

****************************************************************************/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>

#include "maze.h"
#include "draw.h"

#include <dos.h>
#include <values.h>

byte image_buffer[SCREEN_HEIGHT][SCREEN_WIDTH];

#define TEXTURE_SIZE 64
byte texture[TEXTURE_SIZE][TEXTURE_SIZE];
int32 dv_lookup[512];
word  adr[200];

void prepare_lookups() {
	int i;
	dv_lookup[0] = 0;
	for (i=1; i<512; i++)
		dv_lookup[i] = (TEXTURE_SIZE*65536l)/i;
	for (i=1; i<200; i++)
		adr[i] = i*320;
}

void load_texture(const char* filename) {
	FILE *f;
	int i,j;

	f = fopen(filename, "r");
	if (f!=NULL) {
		fread(texture, 1, sizeof(texture)/sizeof(byte), f);
		for (i=0; i<TEXTURE_SIZE; i++)
			for(j=0; j<TEXTURE_SIZE; j++)
				texture[i][j] >>= 2;
		fclose(f);
	}
	else {
		//error("Can't load texture, using chaos.");
		for (i=0; i<TEXTURE_SIZE; i++)
			for(j=0; j<TEXTURE_SIZE; j++)
				texture[i][j] = rand() % 64;
	}
}

typedef struct { int32 start, end; } range;

/* bufor Z; zawiera count informacji o ju� zape�nionych */
/* (pionowymi liniami) przedzia�ach na osi x */
typedef struct {
	int	count;
	range	used[SCREEN_WIDTH+2];
} ZBUFFER;
ZBUFFER zbuffer, tmp;

int check_zbuffer_consistency() {
	int i;
	for (i=0; i < zbuffer.count-1; i++) {
		if (zbuffer.used[i].start > zbuffer.used[i].end)
			return 0;
		if (zbuffer.used[i].end+1 >= zbuffer.used[i+1].start)
			return 0;
	}
	return 1;
}

/* tablica zawiera "zabarwienie" ka�dej pionowej linii */
/* dwa starsze bity okre�laj� jaki kolor (a dok�adniej, kt�ra 64-elementowa  */
/* cz�� LUT) jest wykorzystany */
/*	00 -- bez zmian (szara) */
/*	01 -- czerwoany */
/*	10 -- zielony */
/*	11 -- niebieski */
byte glass[SCREEN_WIDTH];

void init_zbuffer() {
	int i;

	for (i=0; i<SCREEN_WIDTH; i++)
		glass[i] = 0;

	zbuffer.count = 2;

	/* ograniczenie z lewej strony */
	zbuffer.used[0].start	= -MAXLONG/2;
	zbuffer.used[0].end	= -1;

	/* ograniczenie z prawej strony ekranu */
	zbuffer.used[1].start	= SCREEN_WIDTH;
	zbuffer.used[1].end	= +MAXLONG/2;
}

int zbuffer_full() {
	return (zbuffer.used[0].start <= 0 &&
	        zbuffer.used[0].end >= SCREEN_WIDTH);
}

void draw_flat_vline(int yt, int yb, int x, byte color) {
	int y;
	byte* pixel;

	/* poza ekranem (cho� mo�e ten warunek da si� wyeliminowa�?) */
	if (x < 0 || x > SCREEN_WIDTH-1)
		return;

	/* assert(yt < yb) */
	if (yt > yb) {y=yt; yt=yb; yb=y;}

	/* poza ekranem */
	if (yt < 0 && yb < 0)
		return;
	if (yt > SCREEN_HEIGHT-1 && yb > SCREEN_HEIGHT-1)
		return;

	pixel = &image_buffer[0][x];
	/* przycinanie do okna */
	if (yt < 0)
		yt = 0;
	else
		pixel += adr[yt];

	if (yb > SCREEN_HEIGHT-1)
		yb = SCREEN_HEIGHT-1;

	for (y=yt; y<=yb; y++) {
		*pixel = color;
		pixel += SCREEN_WIDTH;
	}
}

void draw_flat_wall(float XA, float ZA, float XB, float ZB, const Edge* E, float dummy1, float dummy2) {
	int32	itmp;
	float	ftmp;
	int32 Ax, Bx;	/* wsp�rz�dna x punkt�w A i B po rzutowaniu  */
			/* perspektywicznym */
	int32 x, dx;
	
	int32 dyt, dyb;	/* fixed-point 16:16 */
	int32 yta, ytb;
	int32 yba, ybb;
	int32 yt, yb;

	int i=0, j=0;

	byte color;

	Ax = perspective_view_xcoord(XA, 0.0, ZA);
	Bx = perspective_view_xcoord(XB, 0.0, ZB);

	/* assert(Ax <= Bx) */
	if (Ax > Bx) {
		itmp = Ax; Ax = Bx; Bx = itmp;
		ftmp = XA; XA = XB; XB = ftmp;
		ftmp = ZA; ZA = ZB; ZB = ftmp;
	}

	/* widoczno�� */
	if (Ax < 0 && Bx < 0)
		return;
	if ((Ax > SCREEN_WIDTH-1) && (Bx > SCREEN_WIDTH-1))
		return;
	dx = Bx-Ax;
	if (!dx)
		return;

	yta = perspective_view_ycoord(XA, MAX_Y, ZA);
	ytb = perspective_view_ycoord(XB, MAX_Y, ZB);

	yba = perspective_view_ycoord(XA, MIN_Y, ZA);
	ybb = perspective_view_ycoord(XB, MIN_Y, ZB);

	dyt = ((ytb-yta) << 16)/dx;
	dyb = ((ybb-yba) << 16)/dx;

	/* obcinanie */
	yt = yta << 16;
	yb = yba << 16;

	/* lightness w fixed-point 16:16 */
	color = (E->A->lightness + E->B->lightness) >> 17;

	tmp.count = 0;
	while (i < zbuffer.count) {

		if (Bx < zbuffer.used[i].start) {
			for (x=Ax; x<=Bx; x++) {
				draw_flat_vline(yt>>16, yb>>16, x, color | glass[x]);
				yt += dyt;
				yb += dyb;
			}
			tmp.used[tmp.count].start = Ax;
			tmp.used[tmp.count].end   = Bx;
			tmp.count++;
			break;
		}

		if (Ax > zbuffer.used[i].end) {
			tmp.used[tmp.count].start = zbuffer.used[i].start;
			tmp.used[tmp.count].end   = zbuffer.used[i].end;
			tmp.count++;
			i++;
			continue;
		}

		if (Ax < zbuffer.used[i].start) {
			for (x=Ax; x < zbuffer.used[i].start; x++) {
				draw_flat_vline(yt>>16, yb>>16, x, color | glass[x]);
				yt += dyt;
				yb += dyb;
			}
			zbuffer.used[i].start = Ax;
			if (Bx <= zbuffer.used[i].end)
				break;
			else {
				Ax = zbuffer.used[i].end+1 - Ax;
				yt = (yta << 16) + dyt * Ax;
				yb = (yba << 16) + dyb * Ax;
				Ax = zbuffer.used[i].end+1;
				continue;
			}
		}

		if (Ax >= zbuffer.used[i].start) {
			if (Bx <= zbuffer.used[i].end)
				break;
			else {
				Ax = zbuffer.used[i].end+1 - Ax;
				yt = (yta << 16) + dyt * Ax;
				yb = (yba << 16) + dyb * Ax;
				Ax = zbuffer.used[i].end+1;
				continue;
			}
		}
	}

	while (i < zbuffer.count) {
		tmp.used[tmp.count].start = zbuffer.used[i].start;
		tmp.used[tmp.count].end   = zbuffer.used[i].end;
		tmp.count++;
		i++;
	}

	i = 0;
	for (j=0; j<tmp.count; j++) {
		/* je�li dwa kolejne zakresy stykaj� si� (np. 1-8 i 9-20) */
		/* po�acz je (np. 1-20) */
		if (i > 0 && zbuffer.used[i-1].end+1 == tmp.used[j].start) {
			zbuffer.used[i-1].end = tmp.used[j].end;
			continue;
		}
		zbuffer.used[i].start = tmp.used[j].start;
		zbuffer.used[i].end   = tmp.used[j].end;
		i++;
	}
	zbuffer.count = i;
}

void draw_shaded_wall(float XA, float ZA, float XB, float ZB, const Edge* E, float dummy1, float dummy2) {
	int32	itmp;
	float	ftmp;
	int32 Ax, Bx;	/* wsp�rz�dna x punkt�w A i B po rzutowaniu  */
			/* perspektywicznym */
	int32 x, dx;
	
	int32 dyt, dyb;	/* fixed-point 16:16 */
	int32 yta, ytb;
	int32 yba, ybb;
	int32 yt, yb;

	int32 c1, c2, dc;

	int i = 0;
	int j = 0;

	Ax = perspective_view_xcoord(XA, 0.0, ZA);
	Bx = perspective_view_xcoord(XB, 0.0, ZB);
	c1 = E->A->lightness;
	c2 = E->B->lightness;

	/* assert(Ax <= Bx) */
	if (Ax > Bx) {
		itmp = Ax; Ax = Bx; Bx = itmp;
		ftmp = XA; XA = XB; XB = ftmp;
		ftmp = ZA; ZA = ZB; ZB = ftmp;
		itmp = c1; c1 = c2; c2 = itmp;
	}

	/* widoczno�� */
	if (Ax < 0 && Bx < 0)
		return;
	if ((Ax > SCREEN_WIDTH-1) && (Bx > SCREEN_WIDTH-1))
		return;
	dx = Bx-Ax;
	if (!dx)
		return;

	yta = perspective_view_ycoord(XA, MAX_Y, ZA);
	ytb = perspective_view_ycoord(XB, MAX_Y, ZB);

	yba = perspective_view_ycoord(XA, MIN_Y, ZA);
	ybb = perspective_view_ycoord(XB, MIN_Y, ZB);

	dyt = ((ytb-yta) << 16)/dx;
	dyb = ((ybb-yba) << 16)/dx;

	dc = (c2-c1)/dx;

	/* obcinanie */
	yt = yta << 16;
	yb = yba << 16;

	tmp.count = 0;
	while (i < zbuffer.count) {

		if (Bx < zbuffer.used[i].start) {
			for (x=Ax; x<=Bx; x++) {
				draw_flat_vline(yt>>16, yb>>16, x, (c1>>16) | glass[x]);
				yt += dyt;
				yb += dyb;
				c1 += dc;
			}
			tmp.used[tmp.count].start = Ax;
			tmp.used[tmp.count].end   = Bx;
			tmp.count++;
			break;
		}

		if (Ax > zbuffer.used[i].end) {
			tmp.used[tmp.count].start = zbuffer.used[i].start;
			tmp.used[tmp.count].end   = zbuffer.used[i].end;
			tmp.count++;
			i++;
			continue;
		}

		if (Ax < zbuffer.used[i].start) {
			for (x=Ax; x < zbuffer.used[i].start; x++) {
				draw_flat_vline(yt>>16, yb>>16, x, (c1>>16) | glass[x]);
				yt += dyt;
				yb += dyb;
				c1 += dc;
			}
			zbuffer.used[i].start = Ax;
			if (Bx <= zbuffer.used[i].end)
				break;
			else {
				Ax = zbuffer.used[i].end - Ax;
				yt = (yta << 16) + dyt * Ax;
				yb = (yba << 16) + dyb * Ax;
				c1 += dc * Ax;
				Ax = zbuffer.used[i].end+1;
				continue;
			}
		}

		if (Ax >= zbuffer.used[i].start) {
			if (Bx <= zbuffer.used[i].end)
				break;
			else {
				Ax = zbuffer.used[i].end - Ax;
				yt = (yta << 16) + dyt * Ax;
				yb = (yba << 16) + dyb * Ax;
				c1 += dc * Ax;
				Ax = zbuffer.used[i].end+1;
			}
		}
	}

	while (i < zbuffer.count) {
		tmp.used[tmp.count].start = zbuffer.used[i].start;
		tmp.used[tmp.count].end   = zbuffer.used[i].end;
		tmp.count++;
		i++;
	}

	i = 0;
	for (j=0; j<tmp.count; j++) {
		/* je�li dwa kolejne zakresy stykaj� si� (np. 1-8 i 9-20) */
		/* po�acz je (np. 1-20) */
		if (i > 0 && zbuffer.used[i-1].end+1 == tmp.used[j].start) {
			zbuffer.used[i-1].end = tmp.used[j].end;
			continue;
		}
		zbuffer.used[i].start = tmp.used[j].start;
		zbuffer.used[i].end   = tmp.used[j].end;
		i++;
	}
	zbuffer.count = i;
}

void draw_glass_wall(float XA, float ZA, float XB, float ZB, const Edge* E, float dummy1, float dummy2) {
	int32	itmp;
	float	ftmp;
	int32 Ax, Bx;	/* wsp�rz�dna x punkt�w A i B po rzutowaniu  */
			/* perspektywicznym */
	int32 x, dx;
	
	int32 dyt, dyb;	/* fixed-point 16:16 */
	int32 yta, ytb;
	int32 yba, ybb;
	int32 yt, yb;

	int i = 0;

	byte color;

	Ax = perspective_view_xcoord(XA, 0.0, ZA);
	Bx = perspective_view_xcoord(XB, 0.0, ZB);

	/* assert(Ax <= Bx) */
	if (Ax > Bx) {
		itmp = Ax; Ax = Bx; Bx = itmp;
		ftmp = XA; XA = XB; XB = ftmp;
		ftmp = ZA; ZA = ZB; ZB = ftmp;
	}

	/* widoczno�� */
	if (Ax < 0 && Bx < 0)
		return;
	if ((Ax > SCREEN_WIDTH-1) && (Bx > SCREEN_WIDTH-1))
		return;
	dx = Bx-Ax;
	if (!dx)
		return;

	yta = perspective_view_ycoord(XA, MAX_Y, ZA);
	ytb = perspective_view_ycoord(XB, MAX_Y, ZB);

	yba = perspective_view_ycoord(XA, MIN_Y, ZA);
	ybb = perspective_view_ycoord(XB, MIN_Y, ZB);

	dyt = ((ytb-yta) << 16)/dx;
	dyb = ((ybb-yba) << 16)/dx;

	/* obcinanie */
	yt = yta << 16;
	yb = yba << 16;

	color = E->color | 32;

	while (i < zbuffer.count) {

		if (Bx < zbuffer.used[i].start) {
			for (x=Ax; x<=Bx; x++) {
				glass[x] = E->color;
				draw_flat_vline(yt>>16, yb>>16, x, color);
				yt += dyt;
				yb += dyb;
			}
			break;
		}

		if (Ax > zbuffer.used[i].end) {
			i++;
			continue;
		}

		if (Ax < zbuffer.used[i].start) {
			for (x=Ax; x < zbuffer.used[i].start; x++) {
				glass[x] = E->color;
				draw_flat_vline(yt>>16, yb>>16, x, color);
				yt += dyt;
				yb += dyb;
			}
			if (Bx <= zbuffer.used[i].end)
				break;
			else {
				Ax = zbuffer.used[i].end+1 - Ax;
				yt = (yta << 16) + dyt * Ax;
				yb = (yba << 16) + dyb * Ax;
				Ax = zbuffer.used[i].end+1;
				continue;
			}
		}

		if (Ax >= zbuffer.used[i].start) {
			if (Bx <= zbuffer.used[i].end)
				break;
			if (Bx > zbuffer.used[i].end) {
				Ax = zbuffer.used[i].end+1 - Ax;
				yt = (yta << 16) + dyt * Ax;
				yb = (yba << 16) + dyb * Ax;
				Ax = zbuffer.used[i].end+1;
				continue;
			}
		}
	}
}

void draw_textured_vline(int yt, int yb, int x, uint32 u) {
	int y, dy;
	uint32 v = 0, dv;
	byte color;
	byte* pixel;

	// poza ekranem (cho� mo�e ten warunek da si� wyeliminowa�?)
	if (x < 0 || x > SCREEN_WIDTH-1)
		return;
	
	// assert(yt < yb)
	if (yt > yb) {y=yt; yt=yb; yb=y;}

	// poza ekranem
	if (yt < 0 && yb < 0)
		return;
	if (yt > SCREEN_HEIGHT-1 && yb > SCREEN_HEIGHT-1)
		return;

	dy = yb-yt;
	//dv = (TEXTURE_SIZE*65536l)/dy;
	dv = dv_lookup[dy];
	 v = 0;

	pixel = &image_buffer[0][x];
	// przycianie do okna
	if (yt < 0) {
		v += dv*(-yt);
		yt = 0;
	}
	else
		pixel += adr[yt];

	if (yb > SCREEN_HEIGHT-1)
		yb = SCREEN_HEIGHT-1;

	u &= 0x3f;
	if (glass[x]) {
		color = glass[x];
		for (y=yt; y<=yb; y++) {
			*pixel = texture[u][(v>>16) & 0x3f] | color;
			pixel += SCREEN_WIDTH;
			v += dv;
		}
	}
	else
		for (y=yt; y<=yb; y++) {
			*pixel = texture[u][(v>>16) & 0x3f];
			pixel += SCREEN_WIDTH;
			v += dv;
		}
}

void draw_textured_wall(float XA, float ZA, float XB, float ZB, const Edge* E, float U1, float U2) {
	int32	itmp;
	float	ftmp;
	int32 Ax, Bx;	// wsp�rz�dna x punkt�w A i B po rzutowaniu 
			// perspektywicznym
	int32 x, dx;

	int32 dyt, dyb;	// fixed-point 16:16
	int32 yta, ytb;
	int32 yba, ybb;
	int32 yt, yb;
	int32 u, du;

	int i = 0;
	int j = 0;

	Ax = perspective_view_xcoord(XA, 0.0, ZA);
	Bx = perspective_view_xcoord(XB, 0.0, ZB);

	// assert(Ax <= Bx)
	if (Ax > Bx) {
		itmp = Ax; Ax = Bx; Bx = itmp;
		ftmp = XA; XA = XB; XB = ftmp;
		ftmp = ZA; ZA = ZB; ZB = ftmp;
		ftmp = U1; U1 = U2; U2 = ftmp;
	}

	// widoczno��
	if (Ax < 0 && Bx < 0)
		return;
	if ((Ax > SCREEN_WIDTH-1) && (Bx > SCREEN_WIDTH-1))
		return;
	dx = Bx-Ax;
	if (!dx)
		return;

	yta = perspective_view_ycoord(XA, MAX_Y, ZA);
	ytb = perspective_view_ycoord(XB, MAX_Y, ZB);

	yba = perspective_view_ycoord(XA, MIN_Y, ZA);
	ybb = perspective_view_ycoord(XB, MIN_Y, ZB);

	dyt = ((ytb-yta) << 16)/dx;
	dyb = ((ybb-yba) << 16)/dx;

	// obcinanie
	yt = yta << 16;
	yb = yba << 16;

	u  = floor((TEXTURE_SIZE*65536.0*U1));
	du = floor((TEXTURE_SIZE*65536.0*(U2-U1))/dx);

	tmp.count = 0;
	while (i < zbuffer.count) {

		if (Bx < zbuffer.used[i].start) {
			for (x=Ax; x<=Bx; x++) {
				draw_textured_vline(yt>>16, yb>>16, x, u>>16);
				yt += dyt;
				yb += dyb;
				u  += du;
			}
			tmp.used[tmp.count].start = Ax;
			tmp.used[tmp.count].end   = Bx;
			tmp.count++;
			break;
		}

		if (Ax > zbuffer.used[i].end) {
			tmp.used[tmp.count].start = zbuffer.used[i].start;
			tmp.used[tmp.count].end   = zbuffer.used[i].end;
			tmp.count++;
			i++;
			continue;
		}

		if (Ax < zbuffer.used[i].start) {
			for (x=Ax; x < zbuffer.used[i].start; x++) {
				draw_textured_vline(yt>>16, yb>>16, x, u>>16);
				yt += dyt;
				yb += dyb;
				u  += du;
			}
			zbuffer.used[i].start = Ax;
			if (Bx <= zbuffer.used[i].end)
				break;
			if (Bx > zbuffer.used[i].end) {
				Ax = zbuffer.used[i].end - Ax;
				yt = (yta << 16) + dyt * Ax;
				yb = (yba << 16) + dyb * Ax;
				u += du * Ax;
				Ax = zbuffer.used[i].end+1;
			}
		}

		if (Ax >= zbuffer.used[i].start) {
			if (Bx <= zbuffer.used[i].end)
				break;
			if (Bx > zbuffer.used[i].end) {
				Ax = zbuffer.used[i].end - Ax;
				yt = (yta << 16) + dyt * Ax;
				yb = (yba << 16) + dyb * Ax;
				u += du * Ax;
				Ax = zbuffer.used[i].end+1;
			}
		}
	}

	while (i < zbuffer.count) {
		tmp.used[tmp.count].start = zbuffer.used[i].start;
		tmp.used[tmp.count].end   = zbuffer.used[i].end;
		tmp.count++;
		i++;
	}

	i = 0;
	for (j=0; j<tmp.count; j++) {
		/* je�li dwa kolejne zakresy stykaj� si� (np. 1-8 i 9-20) */
		/* po�acz je (np. 1-20) */
		if (i > 0 && zbuffer.used[i-1].end+1 == tmp.used[j].start) {
			zbuffer.used[i-1].end = tmp.used[j].end;
			continue;
		}
		zbuffer.used[i].start = tmp.used[j].start;
		zbuffer.used[i].end   = tmp.used[j].end;
		i++;
	}
	zbuffer.count = i;
}

/*
vim ts=8
*/
