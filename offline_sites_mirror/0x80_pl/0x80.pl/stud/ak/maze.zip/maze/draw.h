#ifndef DRAW_H_INCLUDED
#define DRAW_H_INCLUDED
#include "maze.h"

extern byte image_buffer[SCREEN_HEIGHT][SCREEN_WIDTH];

int check_zbuffer_consistency();

#ifdef comment
/* argumenty funkcji draw_..._wall */
typedef void (*draw_wall_function)(
		float,		/* wsp�rz�dna X  */
		float,		/* i Z pierwszego (a) wierzcho�ka �ciany */
		float,		/* wsp�rz�dna X */
		float,		/* i Z drugiego (b) wierzcho�ka �ciany */
		const Edge*,	/* parametry �ciany */
		
		/* wsp�rz�dne parametryczne wiercho�k�w a i b ca�a �ciana */
		/* rozci�ga si� od 0 do 1 */
		float,		/* wsp�rz�dna dla a */
		float		/* wsp�rz�dna dla b */
	);
#endif

/* Funkcja inicjuje bufor Z; ze wzgl�du na charakter sceny 3D bufor ten jest */
/* jednowymiarowy (�ciana bli�sza zawsze ma wi�ksz� wysoko�� ni� �ciana */
/* bardziej oddalona, "relacja" przys�aniania nie zale�y wsp. Y). */
void init_zbuffer();

/* Funkcja zwraca 1 gdy ca�y bufor Z jest zape�niony -- nie ma w�wczas sensu */
/* kontynuowa� wy�wietlanie �cian */
int zbuffer_full();

/* Funkcja rysuj�ca p�ask� �cian�; kolor �ciany zale�y od odleg�o�ci od */
/* obserwatora. */
void draw_flat_wall(
	float XA, float ZA, 
	float XB, float ZB, 
	const Edge *E,
	float dummy1, float dummy2);

/* Funkcja rysuj�ca przezroczyst� �cian�. */
void draw_glass_wall(
	float XA, float ZA, 
	float XB, float ZB, 
	const Edge *E,
	float dummy1, float dummy2);

/* Funkcja rysuj�ca cieniowan� �cian�; cieniowanie na podstawie odleg�o�ci */
/* wierzcho�k�w od obserwatora. */
void draw_shaded_wall(
	float XA, float ZA, 
	float XB, float ZB, 
	const Edge *E,
	float dummy1, float dummy2);

/* Funkcja prekalkuluje pewne rzeczy potrzebne do teksturowania
i adresowania ekranu */
void prepare_lookups();

/* Funkcja rysuj�ca teksturowan� �cian� */
void draw_textured_wall(
	float XA, float ZA, 
	float XB, float ZB, 
	const Edge *E,
	float u0, float u1);

#endif
/*
vim ts=8
*/
