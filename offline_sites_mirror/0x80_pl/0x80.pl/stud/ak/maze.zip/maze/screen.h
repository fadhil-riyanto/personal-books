/* Wojciech Mu�a, 2FD/L03 */
/* 9.04.2004 */

#ifndef SCREEN_H_INCLUDED
#define SCREEN_H_INCLUDED

#include "maze.h"

int  init_screen();
void close_screen();
void set_LUT();

#ifdef BC
void show_image(
	/* wska�nik do bitmapy */
	byte far image[SCREEN_HEIGHT][SCREEN_WIDTH],

	/* funkcja prze�le bitmap� na ekan w czasie pionowego  */
	/* powrotu plamki na monitorze CRT */
	byte wait_v_retrace
	);

void clear_image(
	/* wska�nik do bitmapy */
	byte far image[SCREEN_HEIGHT][SCREEN_WIDTH],

	/* kolor wypelnienia */
	byte color
	);
#endif

#ifdef X11
void show_image(
	/* wska�nik do bitmapy */
	byte image[SCREEN_HEIGHT][SCREEN_WIDTH],
	byte dummy /* nieuzywany */
	);

void clear_image(
	/* wska�nik do bitmapy */
	byte far image[SCREEN_HEIGHT][SCREEN_WIDTH],

	/* kolor wypelnienia */
	byte color
	);

extern Display	*display;	/* display, opisuje po��cznie z X serwerem */
extern Window	window;		/* g��wne okno */
#endif

#endif
/*
vim ts=8
*/
