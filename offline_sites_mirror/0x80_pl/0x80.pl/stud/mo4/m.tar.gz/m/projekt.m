% Metody obliczeniowe: projekt
% Wojciech Mu�a, Dariusz Ostrowski; 2FD/L03
% 2004

function varargout = projekt(varargin)
% PROJEKT Application M-file for projekt.fig
%    FIG = PROJEKT launch projekt GUI.
%    PROJEKT('callback_name', ...) invoke the named callback.

% Last Modified by GUIDE v2.0 13-Jun-2004 09:43:40

if nargin == 0  % LAUNCH GUI

	fig = openfig(mfilename,'reuse');

	% Use system color scheme for figure:
	set(fig,'Color',get(0,'defaultUicontrolBackgroundColor'));

	% Generate a structure of handles to pass to callbacks, and store it. 
	handles = guihandles(fig);
	guidata(fig, handles);

	if nargout > 0
		varargout{1} = fig;
	end

elseif ischar(varargin{1}) % INVOKE NAMED SUBFUNCTION OR CALLBACK

	try
		[varargout{1:nargout}] = feval(varargin{:}); % FEVAL switchyard
	catch
		disp(lasterr);
	end

end

echo off all
% 1. Dane globalne
% 1.1. Parametry statyczne uk�adu
global m1	% masa na p�aszczy�nie [kg]
global m2	% masa zawieszona [kg]
global l	% d�ugo�� nieskr�tnej nici [m]

% 1.2. Parametry pocz�tkowe opisuj�ce uk�ad
global r	% odleg�o�� m1 od otworu [m]; 0 <= r <= l (ozn. odcinek A)
global Vr	% pr�dko�� pocz�tkowa skracania/wyd�u�ania A [m/s]
global fi	% k�t pomi�dzy A a osi� Ox [rad]
global Vfi	% pr�dko�� obrotu A [rad/s]

global initial_vect	% wektor z�o�ony z powy�szych warto�ci

% 1.3. Parametry bie��ce
global cr cVr cfi cVfi	% znaczenie j.w.
global t		% czas

% 2. Parametry dotycz�ce animacji
% 2.1. Dane
global T	% wektor czasu   (length(T)==frames)
global Y	% wektor wynik�w (length(Y)==frames)
% 2.2. Pr�dko��
global fps	% ramki na sek.
global dt	% przyrost czasu co 1 ramke
global frame	% bie��ca ramka
global frames	% ca�kowita liczba ramek

% 2.3. Parametry
global running	% animacja jest uruchomiona
running = 0

global g
g = 9.98	% przyspieszenie ziemskie

%
% funkcja *rzeczywist�* zwraca dodatni� warto�� z pola 'edit'
%
function result = num_from_edit(edit_handle, minv, maxv)
	val = str2double( get(edit_handle, 'String') );
	update = 0
	% pole 'edit' ma niew�a�ciw� zawarto��
	if ~isnumeric(val) | length(val)~=1
		result	= minv;
		val	= minv;
		update	= 1;
	end

	if minv ~= 'any' & val < minv
		val	= minv;
		update	= 1;
	end
	if maxv ~= 'any' & val > maxv
		val	= maxv;
		update	= 1;
	end

	if update
		set(edit_handle, 'String', val);
	end
	result = val

%
% funkcja *rzeczywist�* zwraca dodatni� warto�� z pola 'edit'
%
function result = int_from_edit(edit_handle, minv, maxv)
	val = str2double( get(edit_handle, 'String') );
	update = 0
	% pole 'edit' ma niew�a�ciw� zawarto��
	if ~isnumeric(val) | length(val)~=1
		result	= minv;
		val	= minv;
		update	= 1;
	end

	if minv ~= 'any' & val < minv
		val	= minv;
		update	= 1;
	end
	if maxv ~= 'any' & val > maxv
		val	= maxv;
		update	= 1;
	end

	if update
		set(edit_handle, 'String', floor(val));
	end
	result = floor(val)

%
% funkcja odczytuje warto�ci wpisane przez u�ytkownika
%
function update(handles)
	global m1 m2 l r fi Vr Vfi dt fps frames initial_vect

	m1  = num_from_edit(handles.e_m1, 0, 'any');
	m2  = num_from_edit(handles.e_m2, 0, 'any');
	l   = num_from_edit(handles.e_l , 0, 'any');
	
	r   = num_from_edit(handles.e_r , 0, l);
	Vr  = num_from_edit(handles.e_Vr, 'any', 'any');
	fi  = num_from_edit(handles.e_fi, 0, 360);
	Vfi = num_from_edit(handles.e_Vfi, 'any', 'any')
	
	fps = int_from_edit(handles.e_fps, 0, 100);
	dt  = num_from_edit(handles.e_dt , 0, 'any');
	frames = int_from_edit(handles.e_frames, 0, 'any');

	initial_vect = [Vr Vfi r fi]

%	
% fukcja rysuje uk�ad w podanym stanie
%
function draw(handles, l, r, fi)
	p = handles.drawable;	% axes-rodzic

	% rysowanie fragmentu plaszczyzny
	w = l * (sqrt(2)+0.1);
	x = [-w +w +w -w];
	y = [-w -w +w +w];
	z = [ l  l  l  l];

	color = [0.3 0.5 1.0];
	id=fill3(x,y,z, color, 'Parent', p);
	alpha(id, 0.5);

	% rysowanie masy m2
	x = [0 0];
	y = [0 0];
	z = [l r];
	line(x,y,z, 'Color', 'red', 'LineStyle', '-', 'LineWidth', 2, 'Parent', p);
	text(0,0,r, 'm_2', 'HorizontalAlignment', 'center', 'VerticalAlignment', 'middle', 'Parent', p);
	
	% rysowanie masy m1
	rc = r * cos(fi);
	rs = r * sin(fi);
	x = [0 rc-rs]
	y = [0 rs+rc]
	z = [l l]
	line(x,y,z, 'Color', 'red', 'LineStyle', '-', 'LineWidth', 2, 'Parent', p);
	text(rc-rs,rs+rc,l, 'm_1', 'HorizontalAlignment', 'center', 'VerticalAlignment', 'middle', 'Parent', p);

	axis(p, [-w w -w w 0 w]);
	set(p, 'XGrid', 'on')
	set(p, 'YGrid', 'on')
	set(p, 'ZGrid', 'on')
	% eof

%| ABOUT CALLBACKS:
%| GUIDE automatically appends subfunction prototypes to this file, and 
%| sets objects' callback properties to call them through the FEVAL 
%| switchyard above. This comment describes that mechanism.
%|
%| Each callback subfunction declaration has the following form:
%| <SUBFUNCTION_NAME>(H, EVENTDATA, HANDLES, VARARGIN)
%|
%| The subfunction name is composed using the object's Tag and the 
%| callback type separated by '_', e.g. 'slider2_Callback',
%| 'figure1_CloseRequestFcn', 'axis1_ButtondownFcn'.
%|
%| H is the callback object's handle (obtained using GCBO).
%|
%| EVENTDATA is empty, but reserved for future use.
%|
%| HANDLES is a structure containing handles of components in GUI using
%| tags as fieldnames, e.g. handles.figure1, handles.slider2. This
%| structure is created at GUI startup using GUIHANDLES and stored in
%| the figure's application data using GUIDATA. A copy of the structure
%| is passed to each callback.  You can store additional information in
%| this structure at GUI startup, and you can change the structure
%| during callbacks.  Call guidata(h, handles) after changing your
%| copy to replace the stored original so that subsequent callbacks see
%| the updates. Type "help guihandles" and "help guidata" for more
%| information.
%|
%| VARARGIN contains any extra arguments you have passed to the
%| callback. Specify the extra arguments by editing the callback
%| property in the inspector. By default, GUIDE sets the property to:
%| <MFILENAME>('<SUBFUNCTION_NAME>', gcbo, [], guidata(gcbo))
%| Add any extra arguments after the last argument, before the final
%| closing parenthesis.

% - Obliczenia -------------------------------------------------------
function varargout = calc_Callback(h, eventdata, handles, varargin)
	global T Y dt initial_vect frames frame

	% wy��cz przyciski animacji
	set(handles.b_stop,  'Enable', 'off')
	set(handles.b_start, 'Enable', 'off')
	set(handles.b_calc,  'Enable', 'off')
	set(handles.b_hm2,   'Enable', 'off')
	set(handles.b_tm1,   'Enable', 'off')

	% odczytaj parametry uk�adu wprowadzone przez u�ytkownika	
	update(handles)

	% obliczenia
	if get(handles.function_type, 'Value') == 1
		[T,Y] = ode45('derivative', [0:dt:(frames+1)*dt], initial_vect)
	elseif get(handles.function_type, 'Value') == 2
		[T,Y] = ode23('derivative', [0:dt:(frames+1)*dt], initial_vect)
	end

	% wy��cz przyciski animacji
	set(handles.b_start, 'Enable', 'on')
	set(handles.b_calc,  'Enable', 'on')
	set(handles.b_hm2,   'Enable', 'on')
	set(handles.b_tm1,   'Enable', 'on')

% - Start -------------------------------------------------------------
function varargout = start_Callback(h, eventdata, handles, varargin)
	global T Y l running frame frames

	running = 1
	frame	= 1
	set(handles.b_stop,  'Enable', 'on')
	set(handles.b_start, 'Enable', 'off')

	while (frame <= frames) & running

		Vr  = Y(frame,1)
		Vfi = Y(frame,2)
		r   = Y(frame,3)
		fi  = Y(frame,4)
		t   = T(frame)

		set(handles.v_Vr,  'String', num2str( Vr ))
		set(handles.v_Vfi, 'String', num2str( Vfi ))
		set(handles.v_r,   'String', num2str( r ))
		set(handles.v_fi,  'String', num2str( fi ))
		set(handles.v_t,   'String', num2str( t ))
		draw(handles, l, r, fi)
		drawnow

		frame = frame + 1
	end

	set(handles.b_stop,  'Enable', 'off')
	set(handles.b_start, 'Enable', 'on')

% - Stop -------------------------------------------------------------
function varargout = stop_Callback(h, eventdata, handles, varargin)
	global running
	running = 0

function varargout = plot2_Callback(h, eventdata, handles, varargin)
	global T Y l

	plot(T, Y(:,3)-l)
	Ylim([-l 0])
	Xlabel('t')
	Ylabel('l-r')
	title('Odleglosc m_2 od plaszczyzny')

function varargout = plot1_Callback(h, eventdata, handles, varargin)
	global T Y
	
	polar(Y(:,4), Y(:,3))
	Xlabel('kat')
	Ylabel('r')
	title('Trajektoria m_1')

% ------------------------------------------------------------- eof --
