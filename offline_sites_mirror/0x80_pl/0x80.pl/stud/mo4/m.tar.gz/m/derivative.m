function [Dx]=derivative(t, x)
	global m1 m2 g l

	Vr  = x(1)
	Vfi = x(2)
	r   = x(3)

	if r < 1e-3
		r  = 1e-3
		Vr = 0
	end
	
	if r > l
		r  = l
		Vr = 0
	end

	a = (m1*r*Vfi*Vfi - m2*g)/(m1+m2)
	%b = (-2*r*Vr*Vfi*m1)/(m1*r*r)
	b = (-2*Vr*Vfi)/r
	c = Vr
	d = Vfi
	Dx = [a;  b;   c;  d]
	%     Vr' Vfi' r'  fi'
